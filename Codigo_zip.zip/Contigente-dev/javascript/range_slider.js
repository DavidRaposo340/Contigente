function updateRangeSlider1(val) {
    document.getElementById('textInputSlider1').value=val; 
  }
function updateRangeSlider2(val) {
    document.getElementById('textInputSlider2').value=val; 
  }
  