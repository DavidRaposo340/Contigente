function apply_filter(id) {
    var x = document.getElementById(id);
    console.log(x);
};