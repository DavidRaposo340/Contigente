<?PHP
	
	pg_close($conn);

?>